# SHV-R1A-R5A0 Result Summary

- GPU: Tesla T4
- Support fidelity: {'phase': 'support_integration', 'rows': 48, 'max_forward_nrmse': 0.0, 'min_gradient_cosine': 0.9974037408828735, 'required_gradient_cosine': 0.997, 'passed': True}
- Promotion fidelity: {'phase': 'promotion_integration', 'rows': 48, 'max_forward_nrmse': 0.0, 'min_gradient_cosine': 0.9958204627037048, 'required_gradient_cosine': 0.995, 'passed': True}
- Guard fidelity: {'phase': 'guard_integration', 'rows': 48, 'max_forward_nrmse': 0.0, 'min_gradient_cosine': 0.9984371662139893, 'required_gradient_cosine': 0.995, 'passed': True}
- Forward-resident memory reduction: 0.931131
- Full-step peak memory reduction: 0.529618
- Native step ms: 43.842
- SHV step ms: 95.365
- Throughput ratio (native_time / SHV_time): 0.459724
- Qualifies live Attention integration: **True**

## Gates
- G1_fresh_real_data_contract: True
- G2_support_custom_autograd_fidelity: True
- G3_promotion_custom_autograd_fidelity: True
- G4_guard_custom_autograd_fidelity: True
- G5_custom_saved_state_census: True
- G6_forward_resident_cuda_memory_reduction: True
- G7_full_step_peak_cuda_memory_reduction: True
- R1A_R5A0_QUALIFIES_LIVE_ATTENTION_INTEGRATION: True
